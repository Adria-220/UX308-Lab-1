//input
let radius = .5;
let height = 2.5;

//processing
let volume = Math.PI * radius * radius *height;
//output
console.log(`the volume of a cylinder with radius = ${radius} and height = ${height} is ${volume}`)